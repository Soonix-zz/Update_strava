import requests
import logging
import os

logger = logging.getLogger(__name__)

class MyzoneAPI:
    def __init__(self, email, password):
        self.email = email
        self.password = password
        self.session = requests.Session()
        # TODO: Ajouter les headers si nécessaire pour imiter Chrome
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })
        self.is_logged_in = False

    def login(self):
        """Authentification"""
        # Utilisation d'un cookie de session direct (méthode la plus stable pour contourner les protections)
        myzone_cookie = os.getenv("MYZONE_COOKIE")
        
        if myzone_cookie:
            logger.info("Cookie Myzone fourni dans le .env ! Utilisation de la session manuelle.")
            self.session.headers.update({
                'Cookie': myzone_cookie,
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': 'https://moves.myzone.org/user/',
                'Accept': 'application/json, text/javascript, */*; q=0.01'
            })
            self.is_logged_in = True
            return True
            
        # URL de base de l'authentification (fallback)
        auth_url = "https://auth.myzone.org/authorize?response_type=code&redirect_uri=https://moves.myzone.org/oauth-redirect/&client_id=ClZNiyQcsBVTrEvwYLMmSzzkkpuHCyVrpAqFcRQmxzlatletDkGamKLHvBXPBGNBUsfMWVMGIHdTdvsD&state=PO-PTCNYQFhyeTxO0-0Z8uHJJJnVbEjZlaCc5Sd8Ldg&code_challenge_method=S256&code_challenge=GCIw1nx3yiYnLrALzgDlkEsYceEdDz_6l2pP7o18uMw&scope=openid email profile&audience=ClZNiyQcsBVTrEvwYLMmSzzkkpuHCyVrpAqFcRQmxzlatletDkGamKLHvBXPBGNBUsfMWVMGIHdTdvsD"
        login_url = "https://auth.myzone.org/applogin/"
        
        try:
            logger.info("Étape 1: Initiation de la session OAuth Myzone...")
            res_init = self.session.get(auth_url)
            res_init.raise_for_status()
            
            logger.info("Étape 2: Soumission des identifiants (BETA)...")
            payload = {
                "username": self.email,
                "password": self.password,
                "action": "default"
            }
            res_login = self.session.post(res_init.url, data=payload, allow_redirects=True)
            
            if "moves.myzone.org" in res_login.url or res_login.status_code == 200:
                self.is_logged_in = True
                logger.info("Connexion à Myzone réussie !")
                return True
            else:
                logger.error("La connexion Myzone a échoué. Le site bloque peut-être le script.")
                return False
                
        except Exception as e:
            logger.error(f"Erreur lors de la connexion Myzone: {e}")
            return False

    def get_recent_activities(self, days=21):
        """Récupère les activités des N derniers jours via l'endpoint movesbyrange."""
        if not self.is_logged_in:
            logger.warning("Veuillez vous connecter d'abord.")
            return []

        import datetime
        end_date = datetime.date.today().strftime("%Y-%m-%d")
        start_date = (datetime.date.today() - datetime.timedelta(days=days)).strftime("%Y-%m-%d")
        activities_url = f"https://moves.myzone.org/sessioncalls/movesbyrange/?start={start_date}&end={end_date}"
        
        logger.info(f"Récupération des activités Myzone du {start_date} au {end_date}...")
        try:
            response = self.session.get(activities_url)
            response.raise_for_status()
            res_json = response.json()
            data = res_json.get("data", [])
            
            parsed_activities = []
            
            if isinstance(data, list):
                for item in data:
                    parsed_activities.append({
                        "id": str(item.get("GUID", "mz_unknown")),
                        "guid": item.get("GUID", ""), 
                        "date": item.get("sStart", item.get("isoDate", "")),  # ex: "2026-04-01 12:23:18"
                        "duration_sec": int(item.get("duration", 0)) * 60, # durée en minutes -> secondes
                        "meps": int(item.get("meps", 0)),
                        "calories": int(item.get("calories", 0)),
                        "avg_hr": int(item.get("avgHR", 0)),
                        "peak_hr": int(item.get("peakHR", 0)),
                        "avg_effort": item.get("avgEffort", ""),
                        "title": item.get("activity", "Myzone Workout")
                    })
                logger.info(f"{len(parsed_activities)} activité(s) trouvée(s) sur Myzone.")
            else:
               logger.warning("Structure de donnée Myzone inconnue.")
               logger.debug(f"Données: {res_json}")

            return parsed_activities

        except Exception as e:
            logger.error(f"Erreur lors de la récupération des activités : {e}")
            return []

    def get_activity_graph(self, guid):
        """Récupère la courbe d'effort (movegraph) pour une activité spécifique"""
        if not self.is_logged_in or not guid:
            return []
            
        graph_url = f"https://moves.myzone.org/sessioncalls/movegraph/?guid={guid}"
        logger.info(f"Récupération du graphe pour le GUID {guid}...")
        try:
            res = self.session.get(graph_url)
            res.raise_for_status()
            data = res.json()
            return data.get("graph", [])
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du graphe : {e}")
            return []
